import torch
import torch.nn as nn
from models.GNN_drug import GNN_drug, GNN_drug_2
from models.GNN_cell import GNN_cell
import torch.nn.functional as F

class HMM_GDAN(nn.Module):
    def __init__(self, cluster_predefine, args):
        super().__init__()
        self.batch_size = args.batch_size
        self.layer_drug = args.layer_drug
        self.dim_drug = args.dim_drug
        self.num_feature = args.num_feature
        self.layer_cell = args.layer
        self.dim_cell = args.hidden_dim
        self.dropout_ratio = args.dropout_ratio
        self.relu=nn.ReLU() 
        self.dropout=nn.Dropout(p=self.dropout_ratio)
        # self.alpha=nn.Parameter(torch.tensor([0.]))

        # drug graph branch
        self.GNN_drug = GNN_drug(self.layer_drug, self.dim_drug)

        self.drug_emb = nn.Sequential(
            nn.Linear(self.dim_drug * (self.layer_drug+6), 1024),
            #nn.Linear(self.dim_drug*(self.layer_drug+1), 1024),
            nn.ReLU(),
            # Addi
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(1024,256),
            nn.ReLU(),
            # nn.Linear(128,64),
            # nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio)
        )

        """
        self.GNN_cell2 = GNN_drug_2(self.layer_drug, self.dim_cell)

        self.cell2_emb = nn.Sequential(
            nn.Linear(self.dim_cell * self.layer_cell, 24),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio),
        )
        """

        # cell graph branch
        self.GNN_cell = GNN_cell(self.num_feature, self.layer_cell, self.dim_cell, cluster_predefine)
        print("Final_node",self.GNN_cell.final_node)
        self.cell_emb = nn.Sequential(
            nn.Linear(self.dim_cell * self.GNN_cell.final_node, 1024),
            # nn.Linear(self.dim_cell * self.layer_cell, 1024),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio),
        )
         
        # regressor
        self.regression = nn.Sequential(
            nn.Linear((512+256*5+90)//1, (512+256*5+90)//1),
            # nn.SELU(),
            nn.LeakyReLU(0.1),
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear((512+256*5+90)//1, 512+256*5+90),
            # nn.SELU(),
            nn.LeakyReLU(0.1),
            nn.Dropout(p=self.dropout_ratio),
#            nn.Linear(256, 256//2),
#            nn.ELU(),
#            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(512+256*5+90, 1),
#            nn.LeakyReLU(0.1),
#            nn.Dropout(p=self.dropout_ratio)
        )

        self.linear1=nn.Linear(256,90,bias=False)
        self.linear2=nn.Linear(90,256,bias=False)

        # self.linear3=nn.Linear(256*2,256)
        # self.linear4=nn.Linear(256*2,256)


    def forward(self, drug, cell):
        # forward drug
        x_drug = self.GNN_drug(drug)
        x_drug = self.drug_emb(x_drug)
        # print(x_drug)
        # forward cell
        x_cell = self.GNN_cell(cell)
        x_cell = self.cell_emb(x_cell)
        # x_cell = self.GNN_cell2(cell)
        # x_cell = self.cell2_emb(x_cell)

        # combine drug feature and cell line feature
        # x = torch.cat([x_drug, x_cell], -1)
        
        # print("============================")

        # print(x_drug.size())
        """  
        # pca
        U_d,s_d,V_d=torch.linalg.svd(x_drug,full_matrices=False)
        # print(U_d)
        x_drug=torch.diag(s_d).mm(V_d[:,0:50])
        # print(x_drug.size())
        U_c,s_c,V_c=torch.linalg.svd(x_cell,full_matrices=False)
        x_cell=torch.diag(s_c).mm(V_c[:,0:50])
        """

        U_d=0
        U_c=0

        x_mid = self.linear1(x_drug)
        x_ = self.linear2(x_mid)
        # x = self.relu(x)
        # x = self.dropout(x)
        # print(x.size())
        #x = 0.2*x_cell*x+0.4*x_drug+0.4*x_cell
        # print(x.size())
        
        x=torch.cat([x_cell*x_, x_cell+x_, x_, x_mid, x_drug, x_cell, x_cell+x_drug, x_cell*x_drug],-1)
         
        """
        x_1=self.linear3(torch.cat([x_cell*x,x_drug],dim=-1))
        x_1=self.relu(x_1)
        x_2=self.linear4(torch.cat([x_cell*x,x_cell],dim=-1))
        x_2=self.relu(x_2)
        x = torch.cat([x_1,x_2],dim=-1)
        """

        # x = torch.sum(x,dim=1,keepdim=True)
        # print(x.size())
       
        # print("==========================")
        # print(x.size())

        # x = self.llinear(x)

        x = self.regression(x)
        # x_add =torch.sum(x_cell*x_,dim=1,keepdim=True)
        # x = (1-self.alpha)*x+self.alpha*x_add

        return x

        # return x,U_d[:,0:50],U_c[:,0:50]



import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, GCNConv


class SA(nn.Module):
    def __init__(self, drug_nodes, cell_nodes, drug_edges, cell_edges, args):
        super(SA, self).__init__()
        self.drug_nodes_feature = drug_nodes.to(args.device)
        self.drug_edges = drug_edges.to(args.device)
        self.cell_nodes_feature = cell_nodes.to(args.device)
        self.cell_edges = cell_edges.to(args.device)
        self.dropout = nn.Dropout(args.dropout_ratio)
        self.dropout_ratio = args.dropout_ratio
        self.dim_cell = cell_nodes.size(1)
        self.dim_drug = drug_nodes.size(1)
        self.layer_drug=3
        """
        self.drug_emb = nn.Sequential(
            nn.Linear(self.dim_drug, 256),
            nn.ReLU(),
            nn.Dropout(self.dropout_ratio)
        )
        
        self.cell_emb = nn.Sequential(
            nn.Linear(self.dim_cell, 1024),
            nn.ReLU(),
            nn.Dropout(self.dropout_ratio),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(self.dropout_ratio)
        )
        """

        self.drug_emb = nn.Sequential(
            nn.Linear(self.dim_drug * (self.layer_drug+6), 1024),
            #nn.Linear(self.dim_drug*(self.layer_drug+1), 1024),
            nn.ReLU(),
            # Addi
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(1024,256),
            nn.ReLU(),
            # nn.Linear(128,64),
            # nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio)
        )

        self.cell_emb = nn.Sequential(
            nn.Linear(self.dim_cell*382, 1024),
            # nn.Linear(self.dim_cell * self.layer_cell, 1024),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_ratio),
        )


        self.drug_conv = SAGEConv(self.dim_drug, 256)
        self.cell_conv_1 = SAGEConv(self.dim_cell, 1024)
        self.cell_conv_2 = SAGEConv(1024, 256)

        """
        self.regression = nn.Sequential(
            nn.Linear(512, 512),
            nn.LeakyReLU(0.1),
            nn.Dropout(self.dropout_ratio),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.1),
            nn.Dropout(self.dropout_ratio),
            nn.Linear(512, 1)
        )
        """

   
        # regressor
        self.regression = nn.Sequential(
            nn.Linear((512+256*5+90)//1, (512+256*5+90)//1),
            # nn.SELU(),
            nn.LeakyReLU(0.1),
            nn.Dropout(p=self.dropout_ratio),
            nn.Linear((512+256*5+90)//1, 512+256*5+90),
            # nn.SELU(),
            nn.LeakyReLU(0.1),
            nn.Dropout(p=self.dropout_ratio),
#            nn.Linear(256, 256//2),
#            nn.ELU(),
#            nn.Dropout(p=self.dropout_ratio),
            nn.Linear(512+256*5+90, 1),
#            nn.LeakyReLU(0.1),
#            nn.Dropout(p=self.dropout_ratio)
        )

        self.linear1=nn.Linear(256,90,bias=False)
        self.linear2=nn.Linear(90,256,bias=False)

    def forward(self, drug, cell):
        drug_id = drug.long()
        cell_id = cell.long()
        drug_x = self.drug_nodes_feature
        cell_x = self.cell_nodes_feature
        drug_x = self.drug_emb(drug_x)
        # drug_x = self.dropout(F.relu(self.drug_conv(drug_x, self.drug_edges)))
        cell_x = self.dropout(F.relu(self.cell_conv_1(cell_x, self.cell_edges)))
        cell_x = self.dropout(F.relu(self.cell_conv_2(cell_x, self.cell_edges)))
        # cell_x = self.cell_emb(cell_x)
        drug_x = drug_x.squeeze()
        cell_x = cell_x.squeeze()
        # x = torch.cat([drug_x[drug_id], cell_x[cell_id]], -1)
        x_drug = drug_x[drug_id]
        x_cell = cell_x[cell_id]
        x_mid = self.linear1(x_drug)
        x_ = self.linear2(x_mid)
        # x = self.relu(x)
        # x = self.dropout(x)
        # print(x.size())
        #x = 0.2*x_cell*x+0.4*x_drug+0.4*x_cell
        # print(x.size())
 
        x=torch.cat([x_cell*x_, x_cell+x_, x_, x_mid, x_drug, x_cell, x_cell+x_drug, x_cell*x_drug],-1)
        
        x = self.regression(x)
        return x
